'use strict';

describe('EventListController', function() {


})