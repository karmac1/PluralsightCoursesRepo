'use strict';

describe('eventThumbnail', function() {

});