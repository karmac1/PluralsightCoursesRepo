'use strict';

describe('EditProfileControllerSpec', function() {

});