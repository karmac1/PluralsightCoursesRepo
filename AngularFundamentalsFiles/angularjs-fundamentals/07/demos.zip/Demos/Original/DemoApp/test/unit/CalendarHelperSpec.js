'use strict';

describe('calendarHelper', function() {

});