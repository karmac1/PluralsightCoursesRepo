'use strict';

describe('eventData', function() {

});