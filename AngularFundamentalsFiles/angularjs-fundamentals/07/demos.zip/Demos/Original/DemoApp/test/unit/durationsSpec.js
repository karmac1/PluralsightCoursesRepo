'use strict';

describe('durations', function() {

});